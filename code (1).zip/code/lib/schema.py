"""
Schema definitions and validation for the Multi-Modal Evidence Review system.

Encodes every allowed value list from problem_statement.md so that model
output can be validated and (when invalid) repaired or flagged, rather than
silently writing out-of-spec values to output.csv.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


OUTPUT_COLUMNS = [
    "user_id",
    "image_paths",
    "user_claim",
    "claim_object",
    "evidence_standard_met",
    "evidence_standard_met_reason",
    "risk_flags",
    "issue_type",
    "object_part",
    "claim_status",
    "claim_status_justification",
    "supporting_image_ids",
    "valid_image",
    "severity",
]

CLAIM_OBJECTS = {"car", "laptop", "package"}

CLAIM_STATUS = {"supported", "contradicted", "not_enough_information"}

ISSUE_TYPES = {
    "dent", "scratch", "crack", "glass_shatter", "broken_part",
    "missing_part", "torn_packaging", "crushed_packaging",
    "water_damage", "stain", "none", "unknown",
}

OBJECT_PARTS = {
    "car": {
        "front_bumper", "rear_bumper", "door", "hood", "windshield",
        "side_mirror", "headlight", "taillight", "fender",
        "quarter_panel", "body", "unknown",
    },
    "laptop": {
        "screen", "keyboard", "trackpad", "hinge", "lid", "corner",
        "port", "base", "body", "unknown",
    },
    "package": {
        "box", "package_corner", "package_side", "seal", "label",
        "contents", "item", "unknown",
    },
}

RISK_FLAGS = {
    "none", "blurry_image", "cropped_or_obstructed", "low_light_or_glare",
    "wrong_angle", "wrong_object", "wrong_object_part",
    "damage_not_visible", "claim_mismatch", "possible_manipulation",
    "non_original_image", "text_instruction_present", "user_history_risk",
    "manual_review_required",
}

SEVERITY = {"none", "low", "medium", "high", "unknown"}


@dataclass
class ValidationResult:
    ok: bool
    errors: list[str] = field(default_factory=list)
    repaired: Optional[dict] = None


def validate_and_repair(prediction: dict, claim_object: str) -> ValidationResult:
    """
    Validate a model prediction dict against the allowed-value schema.
    Where possible, repairs minor issues (e.g. wrong type for booleans,
    unknown enum values) by falling back to safe defaults, and records
    every repair as an error so it's visible in logs/eval, rather than
    failing the whole row.
    """
    errors: list[str] = []
    out = dict(prediction)

    # --- booleans -----------------------------------------------------
    for bool_field in ("evidence_standard_met", "valid_image"):
        val = out.get(bool_field)
        if isinstance(val, bool):
            continue
        if isinstance(val, str) and val.strip().lower() in ("true", "false"):
            out[bool_field] = val.strip().lower() == "true"
        else:
            errors.append(f"{bool_field}: invalid value {val!r}, defaulting to false")
            out[bool_field] = False

    # --- claim_status ---------------------------------------------------
    if out.get("claim_status") not in CLAIM_STATUS:
        errors.append(f"claim_status: invalid value {out.get('claim_status')!r}, defaulting to not_enough_information")
        out["claim_status"] = "not_enough_information"

    # --- issue_type -----------------------------------------------------
    if out.get("issue_type") not in ISSUE_TYPES:
        errors.append(f"issue_type: invalid value {out.get('issue_type')!r}, defaulting to unknown")
        out["issue_type"] = "unknown"

    # --- object_part (depends on claim_object) --------------------------
    allowed_parts = OBJECT_PARTS.get(claim_object, set())
    if out.get("object_part") not in allowed_parts:
        errors.append(
            f"object_part: invalid value {out.get('object_part')!r} for "
            f"claim_object={claim_object!r}, defaulting to unknown"
        )
        out["object_part"] = "unknown"

    # --- severity ---------------------------------------------------------
    if out.get("severity") not in SEVERITY:
        errors.append(f"severity: invalid value {out.get('severity')!r}, defaulting to unknown")
        out["severity"] = "unknown"

    # --- risk_flags (semicolon-separated, each must be in RISK_FLAGS) ----
    raw_flags = out.get("risk_flags", "none")
    if isinstance(raw_flags, list):
        flags = raw_flags
    else:
        flags = [f.strip() for f in str(raw_flags).split(";") if f.strip()]
    cleaned_flags = [f for f in flags if f in RISK_FLAGS]
    dropped = set(flags) - set(cleaned_flags)
    if dropped:
        errors.append(f"risk_flags: dropped invalid flags {sorted(dropped)}")
    if not cleaned_flags:
        cleaned_flags = ["none"]
    if len(cleaned_flags) > 1 and "none" in cleaned_flags:
        cleaned_flags = [f for f in cleaned_flags if f != "none"]
    out["risk_flags"] = ";".join(cleaned_flags)

    # --- supporting_image_ids (semicolon-separated, or "none") -----------
    raw_ids = out.get("supporting_image_ids", "none")
    if isinstance(raw_ids, list):
        out["supporting_image_ids"] = ";".join(raw_ids) if raw_ids else "none"
    elif not str(raw_ids).strip():
        out["supporting_image_ids"] = "none"
    else:
        out["supporting_image_ids"] = str(raw_ids).strip()

    # --- text fields: ensure present, non-empty -----------------------
    for text_field in ("evidence_standard_met_reason", "claim_status_justification"):
        if not str(out.get(text_field, "")).strip():
            errors.append(f"{text_field}: missing, using placeholder")
            out[text_field] = "Not provided by model."

    return ValidationResult(ok=(len(errors) == 0), errors=errors, repaired=out)
