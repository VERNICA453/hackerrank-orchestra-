"""
Anthropic API wrapper for a single claim review call.

Responsibilities:
  - load + base64-encode the claim's images (skipping missing files)
  - short-circuit (no API call) when zero images are loadable
  - call the Anthropic Messages API with retries/backoff
  - parse + schema-validate the JSON response
  - cache results on disk, keyed by a hash of every input that affects the
    output, so re-running the pipeline (e.g. after a code fix) doesn't
    re-pay for unchanged rows
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

from . import prompts, schema
from .data_loader import ClaimRow, UserHistory, encode_image, image_id_from_path

try:
    import anthropic
except ImportError:  # pragma: no cover - surfaced clearly at runtime instead
    anthropic = None

DEFAULT_MODEL = os.environ.get("EVIDENCE_REVIEW_MODEL", "claude-sonnet-4-6")
MAX_RETRIES = 4
INITIAL_BACKOFF_SECONDS = 2.0


@dataclass
class CallStats:
    api_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    images_sent: int = 0
    cache_hits: int = 0
    retries: int = 0


def _cache_key(claim: ClaimRow, model: str, strategy: str, image_bytes_sig: str) -> str:
    raw = json.dumps(
        {
            "user_id": claim.user_id,
            "image_paths": claim.image_paths,
            "user_claim": claim.user_claim,
            "claim_object": claim.claim_object,
            "model": model,
            "strategy": strategy,
            "images_sig": image_bytes_sig,
        },
        sort_keys=True,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _extract_json(text: str) -> dict:
    """Best-effort extraction of a JSON object from model output, tolerating
    stray markdown fences or whitespace the model might still emit."""
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"No JSON object found in model output: {text[:200]!r}")
    return json.loads(text[start : end + 1])


class ClaimReviewer:
    def __init__(
        self,
        dataset_root: Path,
        evidence_reqs_all: list[dict],
        model: str = DEFAULT_MODEL,
        strategy: str = "single_pass",
        cache_dir: Path | None = None,
        client=None,
    ):
        self.dataset_root = dataset_root
        self.evidence_reqs_all = evidence_reqs_all
        self.model = model
        self.strategy = strategy
        self.cache_dir = cache_dir
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

        if client is not None:
            self.client = client
        elif anthropic is not None:
            api_key = os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "ANTHROPIC_API_KEY is not set. Export it before running, "
                    "e.g.: export ANTHROPIC_API_KEY=sk-ant-..."
                )
            self.client = anthropic.Anthropic(api_key=api_key)
        else:  # pragma: no cover
            raise RuntimeError("The 'anthropic' package is not installed. Run: pip install anthropic")

    def review_claim(self, claim: ClaimRow, history: UserHistory | None, stats: CallStats) -> dict:
        # --- load images, tolerating missing files -------------------------
        loaded: list[tuple[str, str, str]] = []  # (image_id, media_type, b64)
        missing: list[str] = []
        sig_parts: list[str] = []
        for rel_path in claim.image_paths:
            enc = encode_image(self.dataset_root, rel_path)
            img_id = image_id_from_path(rel_path)
            if enc is None:
                missing.append(img_id)
                continue
            media_type, b64 = enc
            loaded.append((img_id, media_type, b64))
            sig_parts.append(hashlib.sha256(b64.encode("utf-8")).hexdigest()[:16])
        images_sig = ",".join(sig_parts)

        base_row = {
            "user_id": claim.user_id,
            "image_paths": ";".join(claim.image_paths),
            "user_claim": claim.user_claim,
            "claim_object": claim.claim_object,
        }

        # --- no usable images at all -> skip the API call entirely --------
        if not loaded:
            flags = "cropped_or_obstructed"
            return {
                **base_row,
                "evidence_standard_met": False,
                "evidence_standard_met_reason": (
                    "No submitted image files could be loaded "
                    f"(missing: {', '.join(missing) or 'all'})."
                ),
                "risk_flags": flags,
                "issue_type": "unknown",
                "object_part": "unknown",
                "claim_status": "not_enough_information",
                "claim_status_justification": "No usable images were available to evaluate this claim.",
                "supporting_image_ids": "none",
                "valid_image": False,
                "severity": "unknown",
            }

        # --- cache lookup ---------------------------------------------------
        cache_key = _cache_key(claim, self.model, self.strategy, images_sig)
        cache_file = self.cache_dir / f"{cache_key}.json" if self.cache_dir else None
        if cache_file and cache_file.exists():
            stats.cache_hits += 1
            cached = json.loads(cache_file.read_text())
            return {**base_row, **cached["prediction"]}

        system_prompt, messages = prompts.build_messages(
            claim, history, self.evidence_reqs_all, loaded, strategy=self.strategy
        )

        prediction, usage = self._call_with_retries(system_prompt, messages, stats)
        stats.images_sent += len(loaded)

        validated = schema.validate_and_repair(prediction, claim.claim_object)
        out = validated.repaired

        if cache_file:
            cache_file.write_text(
                json.dumps({"prediction": out, "usage": usage, "errors": validated.errors}, indent=2)
            )

        return {**base_row, **out}

    def _call_with_retries(self, system_prompt: str, messages: list[dict], stats: CallStats):
        last_err = None
        for attempt in range(MAX_RETRIES):
            try:
                stats.api_calls += 1
                resp = self.client.messages.create(
                    model=self.model,
                    max_tokens=1024,
                    system=system_prompt,
                    messages=messages,
                )
                text = "".join(block.text for block in resp.content if block.type == "text")
                usage = {
                    "input_tokens": getattr(resp.usage, "input_tokens", 0),
                    "output_tokens": getattr(resp.usage, "output_tokens", 0),
                }
                stats.input_tokens += usage["input_tokens"]
                stats.output_tokens += usage["output_tokens"]
                return _extract_json(text), usage
            except Exception as e:  # noqa: BLE001 - want to retry on anything transient
                last_err = e
                stats.retries += 1
                is_last = attempt == MAX_RETRIES - 1
                if is_last:
                    break
                backoff = INITIAL_BACKOFF_SECONDS * (2**attempt)
                time.sleep(backoff)
        # All retries exhausted: return a safe not_enough_information row
        # rather than crashing the whole batch.
        return (
            {
                "evidence_standard_met": False,
                "evidence_standard_met_reason": f"Model call failed after {MAX_RETRIES} attempts: {last_err}",
                "risk_flags": "manual_review_required",
                "issue_type": "unknown",
                "object_part": "unknown",
                "claim_status": "not_enough_information",
                "claim_status_justification": "Automated review failed; needs manual review.",
                "supporting_image_ids": "none",
                "valid_image": False,
                "severity": "unknown",
            },
            {"input_tokens": 0, "output_tokens": 0},
        )
