"""
Data loading helpers: CSV readers, evidence-requirement lookup, user-history
lookup, and image loading/encoding for the Anthropic vision API.
"""
from __future__ import annotations

import base64
import csv
import mimetypes
from dataclasses import dataclass
from pathlib import Path


@dataclass
class ClaimRow:
    user_id: str
    image_paths: list[str]          # relative paths, e.g. images/test/case_001/img_1.jpg
    user_claim: str
    claim_object: str
    row_index: int


@dataclass
class UserHistory:
    user_id: str
    past_claim_count: str
    accept_claim: str
    manual_review_claim: str
    rejected_claim: str
    last_90_days_claim_count: str
    history_flags: str
    history_summary: str


def load_claims(csv_path: Path) -> list[ClaimRow]:
    rows: list[ClaimRow] = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for i, r in enumerate(reader):
            paths = [p.strip() for p in r["image_paths"].split(";") if p.strip()]
            rows.append(
                ClaimRow(
                    user_id=r["user_id"].strip(),
                    image_paths=paths,
                    user_claim=r["user_claim"],
                    claim_object=r["claim_object"].strip().lower(),
                    row_index=i,
                )
            )
    return rows


def load_user_history(csv_path: Path) -> dict[str, UserHistory]:
    out: dict[str, UserHistory] = {}
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            uh = UserHistory(
                user_id=r["user_id"].strip(),
                past_claim_count=r["past_claim_count"],
                accept_claim=r["accept_claim"],
                manual_review_claim=r["manual_review_claim"],
                rejected_claim=r["rejected_claim"],
                last_90_days_claim_count=r["last_90_days_claim_count"],
                history_flags=r["history_flags"],
                history_summary=r["history_summary"],
            )
            out[uh.user_id] = uh
    return out


def load_evidence_requirements(csv_path: Path) -> list[dict]:
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)


def relevant_requirements(all_reqs: list[dict], claim_object: str) -> list[dict]:
    """Requirements that apply to this object: object-specific + 'all'."""
    return [r for r in all_reqs if r["claim_object"] in (claim_object, "all")]


def image_id_from_path(path: str) -> str:
    """images/test/case_001/img_2.jpg -> img_2"""
    return Path(path).stem


def encode_image(dataset_root: Path, rel_path: str) -> tuple[str, str] | None:
    """
    Returns (media_type, base64_data) for a dataset-relative image path,
    or None if the file is missing (caller should flag as a risk instead
    of crashing the whole row).
    """
    full_path = dataset_root / rel_path
    if not full_path.is_file():
        return None
    media_type = mimetypes.guess_type(str(full_path))[0] or "image/jpeg"
    data = base64.standard_b64encode(full_path.read_bytes()).decode("utf-8")
    return media_type, data
