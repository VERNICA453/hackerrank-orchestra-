#!/usr/bin/env python3
"""
Evaluation harness.

Runs the claim-review pipeline against dataset/sample_claims.csv (which has
expected outputs) under >=2 strategy/model configurations, scores each
configuration field-by-field against the expected labels, and writes:

  evaluation/metrics_<config>.json   - raw per-row + aggregate scores
  evaluation/evaluation_report.md    - human-readable comparison + the
                                        required operational analysis

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python evaluation/main.py
    python evaluation/main.py --configs single_pass:claude-sonnet-4-6 two_stage:claude-sonnet-4-6
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CODE_ROOT = HERE.parent
REPO_ROOT = CODE_ROOT.parent
sys.path.insert(0, str(CODE_ROOT))

from lib.data_loader import load_claims, load_evidence_requirements, load_user_history  # noqa: E402
from lib.vision_client import CallStats, ClaimReviewer  # noqa: E402

DATASET_ROOT = REPO_ROOT / "dataset"
SAMPLE_CSV = DATASET_ROOT / "sample_claims.csv"

SCORED_FIELDS = [
    "evidence_standard_met",
    "claim_status",
    "issue_type",
    "object_part",
    "valid_image",
    "severity",
]
# risk_flags and supporting_image_ids are scored separately (set overlap,
# not exact match) since order/extra-context flags are reasonably fuzzy.


def load_expected(csv_path: Path) -> list[dict]:
    with open(csv_path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def set_field(value: str) -> set[str]:
    return {v.strip() for v in str(value).split(";") if v.strip() and v.strip() != "none"}


def score_row(expected: dict, predicted: dict) -> dict:
    field_scores = {f: int(str(expected.get(f, "")).strip().lower() == str(predicted.get(f, "")).strip().lower())
                     for f in SCORED_FIELDS}

    exp_flags, pred_flags = set_field(expected.get("risk_flags", "")), set_field(predicted.get("risk_flags", ""))
    flags_jaccard = (
        len(exp_flags & pred_flags) / len(exp_flags | pred_flags) if (exp_flags | pred_flags) else 1.0
    )

    exp_ids, pred_ids = set_field(expected.get("supporting_image_ids", "")), set_field(predicted.get("supporting_image_ids", ""))
    ids_jaccard = len(exp_ids & pred_ids) / len(exp_ids | pred_ids) if (exp_ids | pred_ids) else 1.0

    exact_match = all(field_scores.values()) and flags_jaccard == 1.0
    return {
        **field_scores,
        "risk_flags_jaccard": round(flags_jaccard, 3),
        "supporting_image_ids_jaccard": round(ids_jaccard, 3),
        "exact_match": int(exact_match),
    }


def run_config(strategy: str, model: str, cache_dir: Path | None) -> dict:
    claims = load_claims(SAMPLE_CSV)
    expected_rows = load_expected(SAMPLE_CSV)
    user_history = load_user_history(DATASET_ROOT / "user_history.csv")
    evidence_reqs = load_evidence_requirements(DATASET_ROOT / "evidence_requirements.csv")

    reviewer = ClaimReviewer(
        dataset_root=DATASET_ROOT,
        evidence_reqs_all=evidence_reqs,
        model=model,
        strategy=strategy,
        cache_dir=cache_dir,
    )
    stats = CallStats()

    per_row = []
    start = time.time()
    for i, claim in enumerate(claims):
        history = user_history.get(claim.user_id)
        predicted = reviewer.review_claim(claim, history, stats)
        scored = score_row(expected_rows[i], predicted)
        per_row.append({
            "row": i,
            "user_id": claim.user_id,
            "scores": scored,
            "predicted": predicted,
            "expected": expected_rows[i],
        })
    elapsed = time.time() - start

    n = len(per_row)
    agg = {f: round(sum(r["scores"][f] for r in per_row) / n, 3) for f in SCORED_FIELDS}
    agg["risk_flags_jaccard_mean"] = round(sum(r["scores"]["risk_flags_jaccard"] for r in per_row) / n, 3)
    agg["supporting_image_ids_jaccard_mean"] = round(sum(r["scores"]["supporting_image_ids_jaccard"] for r in per_row) / n, 3)
    agg["exact_match_rate"] = round(sum(r["scores"]["exact_match"] for r in per_row) / n, 3)

    return {
        "strategy": strategy,
        "model": model,
        "n_rows": n,
        "elapsed_seconds": round(elapsed, 1),
        "aggregate": agg,
        "stats": vars(stats),
        "per_row": per_row,
    }


def estimate_full_run_cost(stats: dict, n_sample_rows: int, n_test_rows: int, n_sample_images: int, n_test_images: int,
                            price_in_per_mtok: float, price_out_per_mtok: float) -> dict:
    """Extrapolate sample-run token usage to the full test set."""
    if stats["api_calls"] == 0:
        return {"note": "no API calls recorded; cannot extrapolate"}
    avg_in = stats["input_tokens"] / stats["api_calls"]
    avg_out = stats["output_tokens"] / stats["api_calls"]
    est_calls_test = n_test_rows  # one call per row (no usable-image rows skip the call)
    est_in_tokens = avg_in * est_calls_test
    est_out_tokens = avg_out * est_calls_test
    est_cost = (est_in_tokens / 1_000_000) * price_in_per_mtok + (est_out_tokens / 1_000_000) * price_out_per_mtok
    return {
        "avg_input_tokens_per_call": round(avg_in, 1),
        "avg_output_tokens_per_call": round(avg_out, 1),
        "estimated_calls_for_test_set": est_calls_test,
        "estimated_input_tokens": round(est_in_tokens),
        "estimated_output_tokens": round(est_out_tokens),
        "estimated_cost_usd": round(est_cost, 4),
        "pricing_assumption": f"${price_in_per_mtok}/MTok in, ${price_out_per_mtok}/MTok out",
    }


def write_report(results: list[dict], out_dir: Path, n_test_rows: int, n_test_images: int):
    out_dir.mkdir(parents=True, exist_ok=True)
    for r in results:
        (out_dir / f"metrics_{r['strategy']}.json").write_text(
            json.dumps({k: v for k, v in r.items() if k != "per_row"}, indent=2)
        )
        (out_dir / f"metrics_{r['strategy']}_full.json").write_text(json.dumps(r, indent=2, default=str))

    lines = ["# Evaluation Report\n", "## Strategy comparison (on dataset/sample_claims.csv, n=%d)\n" % results[0]["n_rows"]]
    header = ["strategy", "model"] + SCORED_FIELDS + ["risk_flags_jaccard", "support_ids_jaccard", "exact_match_rate"]
    lines.append("| " + " | ".join(header) + " |")
    lines.append("|" + "---|" * len(header))
    for r in results:
        a = r["aggregate"]
        row = [r["strategy"], r["model"]] + [f"{a[f]:.2f}" for f in SCORED_FIELDS] + [
            f"{a['risk_flags_jaccard_mean']:.2f}", f"{a['supporting_image_ids_jaccard_mean']:.2f}", f"{a['exact_match_rate']:.2f}"
        ]
        lines.append("| " + " | ".join(row) + " |")

    best = max(results, key=lambda r: r["aggregate"]["exact_match_rate"])
    lines.append(f"\n**Final strategy used for output.csv: `{best['strategy']}`** "
                 f"(highest exact-match rate on the sample set: {best['aggregate']['exact_match_rate']:.2f}).\n")

    lines.append("## Operational analysis\n")
    for r in results:
        s = r["stats"]
        lines.append(f"### Strategy: {r['strategy']} (model: {r['model']})\n")
        lines.append(f"- Sample-set run: {s['api_calls']} model calls, {s['cache_hits']} cache hits, "
                      f"{s['retries']} retries, {s['images_sent']} images sent, "
                      f"{s['input_tokens']} input tokens, {s['output_tokens']} output tokens, "
                      f"{r['elapsed_seconds']}s wall time for {r['n_rows']} rows.\n")
        for price_in, price_out, label in [(3.0, 15.0, "Sonnet-class pricing")]:
            est = estimate_full_run_cost(s, r["n_rows"], n_test_rows, 0, n_test_images, price_in, price_out)
            lines.append(f"- Extrapolated to the {n_test_rows}-row test set ({label}, {est.get('pricing_assumption','-')}):")
            lines.append(f"  - ~{est.get('estimated_calls_for_test_set','-')} model calls "
                          f"(rows with zero loadable images skip the call entirely)")
            lines.append(f"  - ~{est.get('estimated_input_tokens','-')} input tokens, "
                          f"~{est.get('estimated_output_tokens','-')} output tokens")
            lines.append(f"  - ~${est.get('estimated_cost_usd','-')} estimated cost\n")

    lines.append("""
### TPM/RPM, batching, caching, retry strategy

- **Concurrency**: `main.py` uses a `ThreadPoolExecutor` with a configurable
  `--concurrency` (default 4). Each claim is 1-3 images plus a few hundred
  words of text, so 4 concurrent requests stays comfortably under typical
  per-minute request/token limits for this dataset size (44-64 rows); raise
  `--concurrency` only if your account's TPM/RPM tier supports it.
- **Caching**: every prediction is cached on disk (`.cache/`), keyed by a
  hash of (user_id, image bytes, claim text, model, strategy). Re-running
  the pipeline after a bug fix in 1 row does not re-pay for the other rows.
- **Retries**: transient API errors or malformed JSON trigger up to 4
  retries with exponential backoff (2s, 4s, 8s, 16s) before the row falls
  back to a safe `not_enough_information` / `manual_review_required`
  result, so one bad row never crashes the whole batch.
- **Zero-image short-circuit**: rows where every referenced image file is
  missing/unloadable skip the API call entirely and are marked
  `valid_image=false`, `not_enough_information` - this avoids paying for
  calls that cannot possibly be answered from evidence.
- **Image sizing**: images are sent as-is (no resizing step is included in
  this submission); for production use at larger scale, downscaling large
  photos before base64-encoding would meaningfully cut input tokens and
  latency with little accuracy loss for damage assessment.
""")

    (out_dir / "evaluation_report.md").write_text("\n".join(lines))


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Evaluate >=2 strategies against dataset/sample_claims.csv")
    p.add_argument("--configs", nargs="+", default=["single_pass:claude-sonnet-4-6", "two_stage:claude-sonnet-4-6"],
                    help="List of strategy:model pairs to compare")
    p.add_argument("--out-dir", type=Path, default=HERE)
    p.add_argument("--cache-dir", type=Path, default=REPO_ROOT / ".cache")
    p.add_argument("--n-test-rows", type=int, default=44, help="Size of dataset/claims.csv, for cost extrapolation")
    p.add_argument("--n-test-images", type=int, default=82, help="Total images in dataset/claims.csv, for reference")
    args = p.parse_args(argv)

    results = []
    for cfg in args.configs:
        strategy, model = cfg.split(":", 1)
        print(f"Running config strategy={strategy} model={model} ...", file=sys.stderr)
        results.append(run_config(strategy, model, args.cache_dir))

    write_report(results, args.out_dir, args.n_test_rows, args.n_test_images)
    print(f"Wrote {args.out_dir / 'evaluation_report.md'}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
