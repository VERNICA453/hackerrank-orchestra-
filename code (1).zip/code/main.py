#!/usr/bin/env python3
"""
Multi-Modal Evidence Review - main entry point.

Reads a claims CSV (default: dataset/claims.csv), reviews each row against
its submitted images using a vision-capable Anthropic model, and writes
output.csv with one prediction row per input row, in the exact column order
required by problem_statement.md.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python main.py
    python main.py --input ../dataset/sample_claims.csv --output sample_predictions.csv
    python main.py --strategy two_stage --concurrency 4 --model claude-sonnet-4-6

Run `python main.py --help` for all options.
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from lib import schema
from lib.data_loader import load_claims, load_evidence_requirements, load_user_history
from lib.vision_client import CallStats, ClaimReviewer, DEFAULT_MODEL

HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parent
DEFAULT_DATASET_ROOT = REPO_ROOT / "dataset"


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Run the multi-modal evidence review pipeline.")
    p.add_argument("--input", type=Path, default=DEFAULT_DATASET_ROOT / "claims.csv",
                    help="Input claims CSV (default: dataset/claims.csv)")
    p.add_argument("--output", type=Path, default=REPO_ROOT / "output.csv",
                    help="Output predictions CSV (default: ./output.csv)")
    p.add_argument("--dataset-root", type=Path, default=DEFAULT_DATASET_ROOT,
                    help="Root dir that image_paths/user_history/evidence_requirements are relative to")
    p.add_argument("--model", default=DEFAULT_MODEL,
                    help=f"Anthropic model name (default: {DEFAULT_MODEL})")
    p.add_argument("--strategy", choices=["single_pass", "two_stage"], default="single_pass",
                    help="Prompting strategy (see lib/prompts.py)")
    p.add_argument("--concurrency", type=int, default=4,
                    help="Max parallel API calls (keep modest to respect TPM/RPM limits)")
    p.add_argument("--cache-dir", type=Path, default=REPO_ROOT / ".cache",
                    help="Disk cache dir so reruns don't repay for unchanged rows. Use --no-cache to disable.")
    p.add_argument("--no-cache", action="store_true", help="Disable the on-disk cache")
    p.add_argument("--limit", type=int, default=None, help="Only process the first N rows (for smoke testing)")
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)

    claims = load_claims(args.input)
    if args.limit:
        claims = claims[: args.limit]
    user_history = load_user_history(args.dataset_root / "user_history.csv")
    evidence_reqs = load_evidence_requirements(args.dataset_root / "evidence_requirements.csv")

    cache_dir = None if args.no_cache else args.cache_dir
    reviewer = ClaimReviewer(
        dataset_root=args.dataset_root,
        evidence_reqs_all=evidence_reqs,
        model=args.model,
        strategy=args.strategy,
        cache_dir=cache_dir,
    )

    stats = CallStats()
    results: list[dict | None] = [None] * len(claims)
    start = time.time()

    def work(i_claim):
        i, claim = i_claim
        history = user_history.get(claim.user_id)
        try:
            row = reviewer.review_claim(claim, history, stats)
        except Exception as e:  # noqa: BLE001
            print(f"[row {i}] FAILED: {e}", file=sys.stderr)
            row = {
                "user_id": claim.user_id,
                "image_paths": ";".join(claim.image_paths),
                "user_claim": claim.user_claim,
                "claim_object": claim.claim_object,
                "evidence_standard_met": False,
                "evidence_standard_met_reason": f"Pipeline error: {e}",
                "risk_flags": "manual_review_required",
                "issue_type": "unknown",
                "object_part": "unknown",
                "claim_status": "not_enough_information",
                "claim_status_justification": "Pipeline error; needs manual review.",
                "supporting_image_ids": "none",
                "valid_image": False,
                "severity": "unknown",
            }
        return i, row

    with ThreadPoolExecutor(max_workers=args.concurrency) as ex:
        futures = [ex.submit(work, (i, c)) for i, c in enumerate(claims)]
        done = 0
        for fut in as_completed(futures):
            i, row = fut.result()
            results[i] = row
            done += 1
            print(f"\r[{done}/{len(claims)}] processed", end="", file=sys.stderr)
    print(file=sys.stderr)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=schema.OUTPUT_COLUMNS)
        writer.writeheader()
        for row in results:
            writer.writerow({k: row.get(k, "") for k in schema.OUTPUT_COLUMNS})

    elapsed = time.time() - start
    print(
        f"\nDone in {elapsed:.1f}s | rows={len(claims)} api_calls={stats.api_calls} "
        f"cache_hits={stats.cache_hits} retries={stats.retries} "
        f"input_tokens={stats.input_tokens} output_tokens={stats.output_tokens} "
        f"images_sent={stats.images_sent}\nWrote {args.output}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
